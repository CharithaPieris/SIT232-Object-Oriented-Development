﻿
// BSCP|CS|62|114   Charitha Pieris


using System;

class Program
{
    static void Main(string[] args)
    {
        // Code snippet 1: Using a for loop to calculate sum
        int sum = 0;
        for (int j = -5; sum <= 350; j += 5)
        {
            sum += j;
        }
        Console.WriteLine("Sum: " + sum);

        // Code snippet 2: Using a for loop to print values
        for (int x = 0; x < 500; x += 5)
        {
            Console.WriteLine(x);
        }
    }
}
